Documentation, a full list of included plug-ins, and examples are available at
`<http://packages.python.org/manuel/>`_.

Source code is available from from svn://svn.zope.org/repos/main/manuel/trunk
and can be viewed at `<http://svn.zope.org/manuel/>`_.
