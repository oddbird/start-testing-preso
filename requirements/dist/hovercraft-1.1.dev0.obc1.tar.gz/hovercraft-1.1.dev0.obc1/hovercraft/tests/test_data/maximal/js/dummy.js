/**
 * dummy.js
 *
 * This file does nothing, it's only a placeholder.
 *
 */
