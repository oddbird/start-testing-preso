Document title
--------------

----

Hovercrafts presenter notes
===========================
   
Hovercraft! supports presenter notes. It does this by taking anything in a
what is calles a "notes-admonition" and making that into presenter notes.

.. note:: Hence, this will show up as presenter notes.
    You have still access to a lot of formatting, like

    * Bullet lists

    * And *all* types of **inline formatting**
    
----

.. image:: images/python-logo-master-v3-TM.png

.. note:: 

    You don't have to start the text on the same line as 
    the note, but you can. 
    
    You can also have several paragraphs. You can not have any
    headings of any kind though.
    
    **But you can fake them through bold-text**
    
    And that's useful enough for presentation notes.
    