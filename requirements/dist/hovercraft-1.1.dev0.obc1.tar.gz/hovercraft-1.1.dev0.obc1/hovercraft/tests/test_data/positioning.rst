.. title:: Positioning test

----

No position

----

No position

----

:hovercraft-path: m 100 100 l 200 0 l 0 200

A Path

----

No position

----

No position

----

:data-x: 0
:data-y: 0

Explicit position

-----

:data-rotate: 90

No position, but rotation

----

No position

----

:hovercraft-path: m 100 100 l 200 0 l 0 200

A Path

----

No position

----

:data-rotate-x: 180
:data-z: 1000

No position (because z doesn't count)

----

:data-x: 3000
:data-y: 1000

Explicit position
