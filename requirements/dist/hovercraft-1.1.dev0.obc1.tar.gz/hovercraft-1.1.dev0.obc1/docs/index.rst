.. Hovercraft! documentation master file.

Hovercraft! - Merging convenience and cool!
===========================================

Contents:

.. toctree::
   :maxdepth: 2

   introduction.rst
   usage.rst
   presentations.rst
   designing.rst
   templates.rst
